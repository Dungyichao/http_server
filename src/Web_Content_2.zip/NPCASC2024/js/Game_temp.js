
  //https://stackoverflow.com/questions/5525071/how-to-wait-until-an-element-exists
  function waitForElm(selector) {
    return new Promise(resolve => {
        if (document.querySelector(selector)) {
            return resolve(document.querySelector(selector));
        }

        const observer = new MutationObserver(mutations => {
            if (document.querySelector(selector)) {
                observer.disconnect();
                resolve(document.querySelector(selector));
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    });
  }
var start_game_btn;
waitForElm('#str_btn').then((elm) => {
    //alert("str_btn");
    start_game_btn = document.getElementById("str_btn");
    start_game_btn.addEventListener("click", start);
    start_game_btn.addEventListener("click", assign_zero_round);
    start_game_btn.addEventListener("click", assign_fisrt_round);
    start_game_btn.addEventListener("click", start);
});

var btn_11 ;
waitForElm('#bt11').then((elm) => {
    btn_11 = document.getElementById("bt11");
    btn_11.addEventListener("click", check_click_btn);
});
var btn_12 ;
waitForElm('#bt12').then((elm) => {
    btn_12 = document.getElementById("bt12");
    btn_12.addEventListener("click", check_click_btn);
});
var btn_13 ;
waitForElm('#bt13').then((elm) => {
    btn_13 = document.getElementById("bt13");
    btn_13.addEventListener("click", check_click_btn);
});
var btn_14 ;
waitForElm('#bt14').then((elm) => {
    btn_14 = document.getElementById("bt14");
    btn_14.addEventListener("click", check_click_btn);
}); 

var btn_21 ;
waitForElm('#bt21').then((elm) => {
    btn_21 = document.getElementById("bt21");
    btn_21.addEventListener("click", check_click_btn);
});
var btn_22 ;
waitForElm('#bt22').then((elm) => {
    btn_22 = document.getElementById("bt22");
    btn_22.addEventListener("click", check_click_btn);
});
var btn_23 ;
waitForElm('#bt23').then((elm) => {
    btn_23 = document.getElementById("bt23");
    btn_23.addEventListener("click", check_click_btn);
});
var btn_24 ;
waitForElm('#bt24').then((elm) => {
    btn_24 = document.getElementById("bt24");
    btn_24.addEventListener("click", check_click_btn);
}); 

var btn_31 ;
waitForElm('#bt31').then((elm) => {
    btn_31 = document.getElementById("bt31");
    btn_31.addEventListener("click", check_click_btn);
});
var btn_32 ;
waitForElm('#bt32').then((elm) => {
    btn_32 = document.getElementById("bt32");
    btn_32.addEventListener("click", check_click_btn);
});
var btn_33 ;
waitForElm('#bt33').then((elm) => {
    btn_33 = document.getElementById("bt33");
    btn_33.addEventListener("click", check_click_btn);
});
var btn_34 ;
waitForElm('#bt34').then((elm) => {
    btn_34 = document.getElementById("bt34");
    btn_34.addEventListener("click", check_click_btn);
}); 

var btn_41 ;
waitForElm('#bt41').then((elm) => {
    btn_41 = document.getElementById("bt41");
    btn_41.addEventListener("click", check_click_btn);
});
var btn_42 ;
waitForElm('#bt42').then((elm) => {
    btn_42 = document.getElementById("bt42");
    btn_42.addEventListener("click", check_click_btn);
});
var btn_43 ;
waitForElm('#bt43').then((elm) => {
    btn_43 = document.getElementById("bt43");
    btn_43.addEventListener("click", check_click_btn);
});
var btn_44 ;
waitForElm('#bt44').then((elm) => {
    btn_44 = document.getElementById("bt44");
    btn_44.addEventListener("click", check_click_btn);
}); 

var time_minutes;
waitForElm('#minutes').then((elm) => {
    time_minutes = document.getElementById("minutes");
});

var time_second;
waitForElm('#seconds').then((elm) => {
    time_second = document.getElementById("seconds");
});

var time_miliseconds ;
waitForElm('#miliseconds').then((elm) => {
    time_miliseconds = document.getElementById("miliseconds");
});

var current_num;
waitForElm('#demo').then((elm) => {
    current_num = document.getElementById("demo");
});

var sub_score_btn ;
waitForElm('#sub_score_btn').then((elm) => {
    sub_score_btn = document.getElementById("sub_score_btn");
    sub_score_btn.addEventListener("click", uploadfirebase);
}); 



  
for (var arr_seq=[],i=0;i<32;++i) arr_seq[i]=i + 1;
var arr_first=[];
var arr_two=[];

function shuffle(array) {
  var tmp, current, top = array.length;
  if(top) while(--top) {
    current = Math.floor(Math.random() * (top + 1));
    tmp = array[current];
    array[current] = array[top];
    array[top] = tmp;
  }
  return array;
}

function assign_val_btn(btn_id, ass_value){
	var btn = document.getElementById(btn_id.toString());
	if(ass_value > 32){
		btn.innerHTML = "";
		btn.value = 0;
	}
	else{
		btn.innerHTML = ass_value;
		btn.value = ass_value;
	}	
}

function assign_fisrt_round(){
	current_num.innerHTML = 1;
	for (arr_first=[],i=0;i<16;++i) arr_first[i]=i + 1;
	for (arr_two=[],i=0;i<16;++i) arr_two[i]=i + 17;
	for (arr_seq=[],i=0;i<32;++i) arr_seq[i]=i + 1;


	arr_first = shuffle(arr_first);
	arr_two = shuffle(arr_two);
	arr_first = shuffle(arr_first);
	arr_two = shuffle(arr_two);
	for(var i = 0; i < 4; i++){
		for(var j = 0; j < 4; j++){
			assign_val_btn("bt" + ((i+1) * 10 + (j+1)).toString(), arr_first[4 * i + j]);
		}
	}
}

function assign_zero_round(){
	//stop();
	current_num.innerHTML = 1;
	for(var i = 0; i < 4; i++){
		for(var j = 0; j < 4; j++){
			assign_val_btn("bt" + ((i+1) * 10 + (j+1)).toString(), 0);
		}
	}
}

function assign_second_round(btn_id){
	if(arr_two.length > 0){
		assign_val_btn(btn_id, arr_two[0]);
		arr_two.shift();
	}
	else{
		assign_val_btn(btn_id, 40);
	}
}

function check_click_btn(event){
	// console.log(event.target.id);
	// console.log(event.srcElement.value);
	if(event.srcElement.value == arr_seq[0]){
		arr_seq.shift();
		assign_second_round(event.target.id);
		current_num.innerHTML = arr_seq[0];
	}
	if(arr_seq.length <= 0){
		assign_second_round(event.target.id);	
		clearInterval(interval);
		current_num.innerHTML = 32;	
        uploadfirebase();
	}
}

var startTime, interval;
function start(){
    startTime = Date.now();
    interval = setInterval(function(){
        updateDisplay(Date.now() - startTime);
    });
}

function stop(){
    clearInterval(interval);
    time_minutes.value = 0;
    time_second.value = 0; 
    time_miliseconds.value = 0;
}

function updateDisplay(currentTime){
    // do your stuff
    var min = Math.floor(currentTime / 60000);
    var sec = Math.floor(currentTime / 1000);
    if(min < 1 && sec < 1){
    	time_minutes.value = 0;
    	time_second.value = 0;
    	time_miliseconds.value = currentTime;
    }
    if(sec >= 1 && min < 1){
    	time_minutes.value = 0;
    	time_second.value = Math.floor((currentTime - 60000 * min) / 1000);
    	time_miliseconds.value = currentTime - 1000 * sec;
    }
    if(min >= 1){
    	time_minutes.value = min;
    	time_second.value = Math.floor((currentTime - 60000 * min) / 1000);
    	time_miliseconds.value = currentTime - sec * 1000;
    }
    if(min >= 5){
    	stop();
    }

}

function uploadfirebase(){
    //alert("Start to Upload");
  var playtime = time_minutes.value + "min" + time_second.value + "sec" + time_miliseconds.value;
  console.log(time_minutes.value.toString() + time_second.value.toString() + time_miliseconds.value.toString());
  if(arr_seq.length <= 0){
    var username = prompt("Your time is : " + playtime + "\n Enter player name below");
    if(username.length <= 0){
      alert("You must enter name");
    }
    else{
      var key = database.push().getKey();
      database.child(key).set({
        username: username,
        time: ((time_minutes.value - 0) * 60000 + (time_second.value-0) * 1000 + (time_miliseconds.value - 0)).toString()
      }).then(
        () => {
            alert("Success Uploaded 成功上傳");
        }
      ).catch((err) => {
        alert("Failed 失敗上傳: ", err);
      });
      assign_zero_round();
        for (arr_seq=[],i=0;i<32;++i) arr_seq[i]=i + 1;
      stop();
    }
  }
  else{
    alert("Finish the game and upload score!!");
  }
}


//$(document).on('shown.bs.modal', stop);
$(document).on('shown.bs.modal', assign_zero_round);
/* $(document).on('hidden.bs.modal', stop);
$(document).on('hidden.bs.modal', assign_zero_round); */
$(document).on('hidden.bs.modal', function () {
 location.reload();
});
  
//firebase.initializeApp(firebaseConfig);
//var database = firebase.database().ref().child('scores');  //scores