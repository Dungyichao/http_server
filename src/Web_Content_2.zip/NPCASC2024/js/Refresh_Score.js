
  function sort_score(){
    var all_data = [];
    database.once('value', function(snapshot){
      if(snapshot.exists()){
        snapshot.forEach(function(data){
          var val = data.val();
          var temp_arr = [val.time, val.username];
          all_data.push(temp_arr);
        });      
        all_data = all_data.sort(Comparator);
        all_data.forEach(sort_array);
      }
    });
  }
  
  function sort_array(item, index){
    var display_time = "";
    var current_time = item[0];
    var min = Math.floor(current_time / 60000);
      var sec = Math.floor(current_time / 1000);
      if(min < 1 && sec < 1){
        display_time = "0 min 0 sec." + current_time;
      }
      if(sec >= 1 && min < 1){
        display_time = "0 min " +  (Math.floor((current_time - 60000 * min) / 1000)).toString() + " sec." + (current_time - 1000 * sec).toString();
      }
      if(min >= 1){
        display_time = min + " min " +  (Math.floor((current_time - 60000 * min) / 1000)).toString() + " sec." + (current_time - 1000 * sec).toString();
      }
    var content = '';
    content += '<tr>';
    content += '<td>' + (index + 1).toString() + '</td>';
    content += '<td>' + item[1] + '</td>';
    content += '<td>' + display_time + '</td>';
    content += '</tr>';
    $('#tbody_ele').append(content);
  
  }
  
  function Comparator(a, b) {
    return a[0] - b[0];
   }
  
  //display_score_table();
  sort_score();
  
  
  
  