var firebaseConfig = {
    apiKey: "AIzaSyAkU7OmFS2V1CXLD8fOYr-0rutookFTeak",
    authDomain: "npcasc2020.firebaseapp.com",
    databaseURL: "https://npcasc2020.firebaseio.com",
    projectId: "npcasc2020",
    storageBucket: "npcasc2020.appspot.com",
    messagingSenderId: "103760217336",
    appId: "1:103760217336:web:92b17e1d4e11e39635670d",
    measurementId: "G-NDY3JGGC8H"
  };
  var version = 111;
  
  firebase.initializeApp(firebaseConfig);

  var database = firebase.database().ref().child('scores');  //scores 1~32
  var database_bingo_answer = firebase.database().ref().child('Bingo_Answer'); //Bingo Answer
  var database_bingo_result = firebase.database().ref().child('Bingo_Result'); //User's Bingo Enter

 