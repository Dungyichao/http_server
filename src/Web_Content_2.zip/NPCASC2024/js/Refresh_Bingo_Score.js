//Get User Bingo
async function Get_User_Bingo(){
    var all_data = [];
    await database_bingo_result.once('value', function(snapshot){
      if(snapshot.exists()){
        snapshot.forEach(function(data){
          var val = data.val();
          var temp_arr = [val.username, val.bingo, 0];
          all_data.push(temp_arr);
        });      
      }
    });
    return await all_data;
    
}

//Get Answer Bingo
async function Get_Answer_Bingo(){
    var all_data = [];
    var split_string;
    await database_bingo_answer.once('value', function(snapshot){
      if(snapshot.exists()){
        snapshot.forEach((childSnapshot) => {
            //console.log(childSnapshot.key)                  // "answers"
            //console.log(childSnapshot.val())                // "1,2,3,4,"
            var temp = childSnapshot.val();
            split_string = temp.split(",");
            split_string.forEach((data)=>{
                all_data.push(data);
            })
         })
      }
    });
    return await all_data;
}

//compare A(user bingo) / B(called val) array and return 1 array with only 1(match)/0. size is the same as A
 async function Get_Bingo_Match_by_Called(User_Bingo_arr, Called_arr){
  var match_arr = [];

  var user_name =  User_Bingo_arr[0];
  var user_bingo =  User_Bingo_arr[1].split(",");
  var user_line; // =  User_Bingo_arr[2];

  user_bingo.forEach(async (data) => {
    if(Called_arr.includes(data)){
      match_arr.push(1);
    }
    else{
      match_arr.push(0);
    } 
  }); 

  user_line = Calculate_Row_line(match_arr, 5);
  return [user_name, user_bingo, match_arr, user_line];
}

async function Review_all_user_bingo_match(){
  var Called_ans = await Get_Answer_Bingo();
  var All_user = await Get_User_Bingo(); 
  var temp_arr = [];

  All_user.forEach(async (data) =>{
    var temp = await Get_Bingo_Match_by_Called(data, Called_ans);
    temp_arr.push(temp);
  })
  return temp_arr;
}

function Calculate_Row_line(Match_arr, dimension){
  var row_line = 0;
/* 
0, 1, 2, 3, 4, 
5, 6, 7, 8, 9,
10,11,12,13,14,
15,16,17,18,19,
20,21,22,23,24,
*/
  //horizontal
  for(let row_idx = 0; row_idx < dimension; row_idx++){
    var temp_arr = Match_arr.slice(row_idx * dimension, row_idx * dimension + dimension);
    var sum = temp_arr.reduce((a, b) => a + b, 0);
    if(sum == dimension){
      row_line++;
    }
  }
  //vertical
  for(let col_idx = 0; col_idx < dimension; col_idx++){
    var temp_sum = 0;
    for(let idx = 0; idx < dimension; idx++){
      temp_sum += Match_arr[col_idx + idx * dimension];
    }
    if(temp_sum == dimension){
      row_line++;
    }
  }
  //diagonal from left idx: 0, 6, 12, 18, 24
  var dia_left_sum = 0;
  for(let dia_left = 0; dia_left< dimension * dimension; dia_left+=6){
    dia_left_sum += Match_arr[dia_left];
  }
  if(dia_left_sum == dimension){
    row_line++;
  }
  //diagonal from right idx: 4, 8, 12, 16, 20
  var dia_right_sum = 0;
  for(let dia_left = 4; dia_left < dimension * dimension - 4; dia_left+=4){
    dia_right_sum += Match_arr[dia_left];
  }
  if(dia_right_sum == dimension){
    row_line++;
  }
  return row_line;
}

function sort_bingo_score(all_data){
  all_data = all_data.sort(Bingo_Comparator);
  all_data.forEach(sort_bingo_array);
}

function sort_bingo_array(item, index){
  var content = '';
  content += '<tr>';
  content += '<td>' + (index + 1).toString() + '</td>';
  content += '<td>' + item[0] + '</td>';
  content += '<td>' + item[3] + '</td>';
  content += '</tr>';
  $('#tbody_ele_bingo').append(content);
}

function Bingo_Comparator(a, b) {
  return  b[3] - a[3] ;
 }

const process_data = async function (){
  var temp_return= await Review_all_user_bingo_match();
  //console.log(temp_return);
  sort_bingo_score(temp_return);
};

process_data();




