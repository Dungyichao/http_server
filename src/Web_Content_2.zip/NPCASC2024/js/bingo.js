var current_need_assign_value = 1;


var bingo_current_num;
waitForElm('#bingo_demo').then((elm) => {
    bingo_current_num = document.getElementById("bingo_demo");
});

var bingobtn_11 ;
waitForElm('#bingo_bt11').then((elm) => {
    bingobtn_11 = document.getElementById("bingo_bt11");
    bingobtn_11.addEventListener("click", bingo_check_click_btn);
});
var bingobtn_12 ;
waitForElm('#bingo_bt12').then((elm) => {
    bingobtn_12 = document.getElementById("bingo_bt12");
    bingobtn_12.addEventListener("click", bingo_check_click_btn);
});
var bingobtn_13 ;
waitForElm('#bingo_bt13').then((elm) => {
    bingobtn_13 = document.getElementById("bingo_bt13");
    bingobtn_13.addEventListener("click", bingo_check_click_btn);
});
var bingobtn_14 ;
waitForElm('#bingo_bt14').then((elm) => {
    bingobtn_14 = document.getElementById("bingo_bt14");
    bingobtn_14.addEventListener("click", bingo_check_click_btn);
}); 
var bingobtn_15 ;
waitForElm('#bingo_bt15').then((elm) => {
    bingobtn_15 = document.getElementById("bingo_bt15");
    bingobtn_15.addEventListener("click", bingo_check_click_btn);
}); 

var bingobtn_21 ;
waitForElm('#bingo_bt21').then((elm) => {
    bingobtn_21 = document.getElementById("bingo_bt21");
    bingobtn_21.addEventListener("click", bingo_check_click_btn);
});
var bingobtn_22 ;
waitForElm('#bingo_bt22').then((elm) => {
    bingobtn_22 = document.getElementById("bingo_bt22");
    bingobtn_22.addEventListener("click", bingo_check_click_btn);
});
var bingobtn_23 ;
waitForElm('#bingo_bt23').then((elm) => {
    bingobtn_23 = document.getElementById("bingo_bt23");
    bingobtn_23.addEventListener("click", bingo_check_click_btn);
});
var bingobtn_24 ;
waitForElm('#bingo_bt24').then((elm) => {
    bingobtn_24 = document.getElementById("bingo_bt24");
    bingobtn_24.addEventListener("click", bingo_check_click_btn);
}); 
var bingobtn_25 ;
waitForElm('#bingo_bt25').then((elm) => {
    bingobtn_25 = document.getElementById("bingo_bt25");
    bingobtn_25.addEventListener("click", bingo_check_click_btn);
}); 

var bingobtn_31 ;
waitForElm('#bingo_bt31').then((elm) => {
    bingobtn_31 = document.getElementById("bingo_bt31");
    bingobtn_31.addEventListener("click", bingo_check_click_btn);
});
var bingobtn_32 ;
waitForElm('#bingo_bt32').then((elm) => {
    bingobtn_32 = document.getElementById("bingo_bt32");
    bingobtn_32.addEventListener("click", bingo_check_click_btn);
});
var bingobtn_33 ;
waitForElm('#bingo_bt33').then((elm) => {
    bingobtn_33 = document.getElementById("bingo_bt33");
    bingobtn_33.addEventListener("click", bingo_check_click_btn);
});
var bingobtn_34 ;
waitForElm('#bingo_bt34').then((elm) => {
    bingobtn_34 = document.getElementById("bingo_bt34");
    bingobtn_34.addEventListener("click", bingo_check_click_btn);
}); 
var bingobtn_35 ;
waitForElm('#bingo_bt35').then((elm) => {
    bingobtn_35 = document.getElementById("bingo_bt35");
    bingobtn_35.addEventListener("click", bingo_check_click_btn);
}); 

var bingobtn_41 ;
waitForElm('#bingo_bt41').then((elm) => {
    bingobtn_41 = document.getElementById("bingo_bt41");
    bingobtn_41.addEventListener("click", bingo_check_click_btn);
});
var bingobtn_42 ;
waitForElm('#bingo_bt42').then((elm) => {
    bingobtn_42 = document.getElementById("bingo_bt42");
    bingobtn_42.addEventListener("click", bingo_check_click_btn);
});
var bingobtn_43 ;
waitForElm('#bingo_bt43').then((elm) => {
    bingobtn_43 = document.getElementById("bingo_bt43");
    bingobtn_43.addEventListener("click", bingo_check_click_btn);
});
var bingobtn_44 ;
waitForElm('#bingo_bt44').then((elm) => {
    bingobtn_44 = document.getElementById("bingo_bt44");
    bingobtn_44.addEventListener("click", bingo_check_click_btn);
}); 
var bingobtn_45 ;
waitForElm('#bingo_bt45').then((elm) => {
    bingobtn_45 = document.getElementById("bingo_bt45");
    bingobtn_45.addEventListener("click", bingo_check_click_btn);
}); 

var bingobtn_51 ;
waitForElm('#bingo_bt51').then((elm) => {
    bingobtn_51 = document.getElementById("bingo_bt51");
    bingobtn_51.addEventListener("click", bingo_check_click_btn);
});
var bingobtn_52 ;
waitForElm('#bingo_bt52').then((elm) => {
    bingobtn_52 = document.getElementById("bingo_bt52");
    bingobtn_52.addEventListener("click", bingo_check_click_btn);
});
var bingobtn_53 ;
waitForElm('#bingo_bt53').then((elm) => {
    bingobtn_53 = document.getElementById("bingo_bt53");
    bingobtn_53.addEventListener("click", bingo_check_click_btn);
});
var bingobtn_54 ;
waitForElm('#bingo_bt54').then((elm) => {
    bingobtn_54 = document.getElementById("bingo_bt54");
    bingobtn_54.addEventListener("click", bingo_check_click_btn);
}); 
var bingobtn_55 ;
waitForElm('#bingo_bt55').then((elm) => {
    bingobtn_55 = document.getElementById("bingo_bt55");
    bingobtn_55.addEventListener("click", bingo_check_click_btn);
}); 

var sub_bingo_score_btn ;
waitForElm('#sub_bingo_score_btn').then((elm) => {
    sub_bingo_score_btn = document.getElementById("sub_bingo_score_btn");
    sub_bingo_score_btn.addEventListener("click", upload_bingo_result);
}); 


function bingo_check_click_btn(event){
	//console.log(event.target.id);
    //console.log(event.srcElement.innerHTML);
    if(event.srcElement.value == "X" || event.srcElement.value == 0){
        assign_val_btn(event.target.id, current_need_assign_value);
        current_need_assign_value++;
        event.srcElement.style.backgroundColor = "#FFFFFF"; //#555555
    }
    else if(event.srcElement.value == current_need_assign_value - 1){
        assign_val_btn(event.target.id, "X");
        current_need_assign_value--;
        event.srcElement.style.backgroundColor = "#555555"; //#555555
    }

    if(current_need_assign_value <= 25){
        bingo_current_num.innerHTML = current_need_assign_value;
        bingo_current_num.value = current_need_assign_value;
    }
    else if(current_need_assign_value > 25){
        bingo_current_num.value = current_need_assign_value;
    }
}

function upload_bingo_result(){
    if(bingo_current_num.value > 25){
        const bingo_arr = prepare_bingo_array();   
        var arr_string =  bingo_arr.toString(); 
        var username = prompt("Enter player name below \n輸入姓名");
        if(username.length <= 0){
          alert("You must enter your name");
        }
        else{
          var key = database_bingo_result.push().getKey();
          database_bingo_result.child(key).set({
            username: username,
            bingo: arr_string
          }).then(
            () => {
                alert("Success Uploaded 成功上傳");
            }
          ).catch((err) => {
            alert("Failed 失敗上傳: ", err);
          });
          
        }
    }
    else{
        alert("Key in all 1~25 in each cell and upload score!! \n 按所有X的格子以輸入1~25");
    }

}

function get_btn_value(btn_id){
    var btn = document.getElementById(btn_id.toString());
    return btn.value;
}

function prepare_bingo_array(){
    const bingo_arr = [];
    for (let row = 0; row <= 4; row++) {
        for (let col = 0; col <= 4; col++) {
            var btn_id = "bingo_bt" + (row + 1).toString() + (col + 1).toString();
            bingo_arr[row * 5 + col] = get_btn_value(btn_id);       
        }            
    }
    return bingo_arr;
}